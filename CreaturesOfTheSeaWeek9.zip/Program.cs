﻿using System;

namespace CreaturesOfTheSea
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");


            Game game = new Game();



        }
    }
}
